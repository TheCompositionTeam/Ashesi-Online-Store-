//Regular Expression to use

var myidcheck = /^([0-9]{4,4})(2020)$/gm;

//Edit the html for the necessary addition 

//Create a function that validate the search field using the regular expression above

//Create a function that checks if any gender has been selected

//Create a function to check if the selected item is 'CS'

//A function to be excuted when the search button is clicked. 
//This function calls all other functions
function validate(){

	//
	alert("validting...");

	//call function to validate search field
	//call function for gender
	//call funtion for select item
}

//In all cases, provide appropriate alert to indicate the status of validation

//Edit the html for the necessary addition

//sample function
function functionname(){
	//condition to validate
	//if true alert results and continue
	//if false alert results and exit
	//to exit just use the command "return false;"
}