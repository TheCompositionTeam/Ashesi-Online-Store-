<?php

//db credentials
require('dbcon.php');
/**
 * @author Trixy Quaye
 * @version 1.0
 */
class KDB
{
	public $database = null;
	public $results = null;
	
	/**
	*
	*@return boolean
	*/

	public function dbconnection(){
		$this->database = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE);
		if(mysqli_connect_errno()){
			return false;

		}
		else{
			return false;
		}
	}

	/**
	*@param connection and query 
	*@return boolean
	*/
	public function dbquery($sql){
		if(!$this->dbconnection()){
			return false;
		}else{
			return true;
		}

		$this->results = mysqli_connect($this->database, $sql);
		if($this->results ==false){
			return false;

		}else{
			return true;
		}
	}

	public function dbfetchresults(){
		if ($this->results==null) {
			return false;
		}
		elseif ($this->results==false) {
			return false;
		}
		return mysqli_fetch_assoc($this->results);

	}
		
}

?>