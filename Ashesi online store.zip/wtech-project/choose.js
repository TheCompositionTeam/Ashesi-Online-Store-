const realFileBtn = document.getElementById("real-file");
const cBtn = document.getElementById("custom-button");
const txt = document.getElementById("custom-text");

cBtn.addEventListener("click", function(){
	realFileBtn.click();
});

realFileBtn.addEventListener("change", function(){
	if(realFileBtn.value){
		txt.innerHTML = realFileBtn.value.match(/[\/\\]([\w\d\s\.\-\(\)]+)$/)[1];
	}

	else {
		txt.innerHTML = "No file Chosen";
	}
});