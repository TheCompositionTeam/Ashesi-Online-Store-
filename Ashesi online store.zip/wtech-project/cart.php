<?php  
	session_start();
	echo $_SESSION['cart'];
	$a = $_SESSION['cart'];
	echo $a;
	$db = mysqli_connect("localhost", "ransford_nyarko", "ransford_nyarko", "webtech_fall2019_ransford_nyarko");
	$res = mysqli_query($db, "SELECT * FROM product WHERE productName ='$a'");

	if (mysqli_query($db, "SELECT * FROM product WHERE productName ='$a'")) {
		echo "true";
	}

	  while ($r=mysqli_fetch_array($res)) {
	  	$id = $r['uid'];
	  	$a = $r['productName'];
	  	$price = $r['price'];
	  	$qua = "1";
	  	echo $price ;
	  	$sql = "INSERT INTO `cart` VALUES ('$id' ,'$a','$price','1')";
	  	mysqli_query($db, $sql);
	  }

	  $result = mysqli_query($db, "SELECT * FROM cart")
	

?>

<!DOCTYPE html>
<html>
<head>
	<title> Cart</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>
<table class="table table-striped">
  <thead>
    <tr>
      <th scope="col">Product Name</th>
      <th scope="col">Price</th>
      <th scope="col">Quantity</th>
    </tr>
  </thead>
  <tbody>
   <?php 
   	  while ($r=mysqli_fetch_array($result)) {
	  	$id = $r['id'];
	  	$product = $r['product'];
	  	$price = $r['price'];
	  	$qua = "1";
	  	echo "<tr>";
   		echo "<td>".$product."</td>";
     	echo "<td>".$price."</td>";
      	echo "<td>1</td>";

  
	  	
	  }

    ?>
  </tbody>
</table>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>
</html>