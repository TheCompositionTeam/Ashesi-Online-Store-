// validation script here
const inputs = document.querySelectorAll('input');


const patterns ={
	password:/^[\w@-]
}